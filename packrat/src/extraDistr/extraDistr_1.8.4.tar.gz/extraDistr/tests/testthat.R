library(testthat)
library(extraDistr)

test_check("extraDistr")
